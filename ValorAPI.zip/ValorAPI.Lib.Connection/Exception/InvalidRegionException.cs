﻿namespace ValorAPI.Lib.Connection.Exception
{
    public class InvalidRegionException : System.Exception
    { 
    }
}
