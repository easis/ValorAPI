﻿namespace ValorAPI.Lib.Connection.Exception
{
    public class EmptyKeyringException : System.Exception
    {
    }
}
