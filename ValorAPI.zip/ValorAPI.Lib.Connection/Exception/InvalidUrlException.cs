﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ValorAPI.Lib.Connection.Error
{
    public class InvalidUrlException : System.Exception
    {
    }
}
