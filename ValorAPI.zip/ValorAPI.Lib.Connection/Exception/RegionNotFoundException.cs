﻿namespace ValorAPI.Lib.Connection.Exception
{
    public class RegionNotFoundException : System.Exception
    {
    }
}
