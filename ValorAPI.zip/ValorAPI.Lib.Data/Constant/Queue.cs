﻿using System;

namespace ValorAPI.Lib.Data.Constant
{
    public static class Queue
    {
        public static readonly string COMPETITIVE = "competitive";
        public static readonly string UNRATED = "unrated";
        public static readonly string SPIKERUSH = "spikerush";
    }
}
