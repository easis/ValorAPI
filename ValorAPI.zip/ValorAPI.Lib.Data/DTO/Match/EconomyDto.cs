﻿namespace ValorAPI.Lib.Data.DTO.Match
{
    public class EconomyDto
    {
        public int loadoutValue;

        public string weapon;

        public string armor;

        public int remaining;

        public int spent;
    }
}
