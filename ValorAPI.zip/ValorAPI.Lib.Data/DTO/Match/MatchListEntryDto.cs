﻿namespace ValorAPI.Lib.Data.DTO.Match
{
    public class MatchListEntryDto
    {
        public string matchId;

        public long gameStartTimeMillis;

        public string teamId;
    }
}
