﻿namespace ValorAPI.Lib.Data.DTO.Match
{
    public class AbilityDto
    {
        public string grenadeEffects;

        public string ability1Effects;

        public string ability2Effects;

        public string ultimateEffects;
    }
}
