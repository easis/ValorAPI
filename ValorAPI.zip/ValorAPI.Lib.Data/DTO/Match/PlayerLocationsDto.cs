﻿namespace ValorAPI.Lib.Data.DTO.Match
{
    public class PlayerLocationsDto
    {
        public string puuid;

        public float viewRadians;

        public LocationDto location;
    }
}
