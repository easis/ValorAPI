﻿namespace ValorAPI.Lib.Data.DTO.Match
{
    public class AbilityCastsDto
    {
        public int grenadeCasts;

        public int ability1Casts;

        public int ability2Casts;

        public int ultimateCasts;
    }
}
