﻿namespace ValorAPI.Lib.Data.DTO.Match
{
    public class DamageDto
    {
        /// <summary>
        /// PUUID
        /// </summary>
        public string receiver;

        public int damage;

        public int legshots;

        public int bodyshots;

        public int headshots;
    }
}
