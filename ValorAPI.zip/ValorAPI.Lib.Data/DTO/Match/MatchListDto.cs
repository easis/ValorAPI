﻿namespace ValorAPI.Lib.Data.DTO.Match
{
    public class MatchListDto
    {
        public string puuid;

        public MatchListEntryDto[] history;
    }
}
