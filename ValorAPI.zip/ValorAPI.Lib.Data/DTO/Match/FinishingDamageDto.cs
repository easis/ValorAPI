﻿namespace ValorAPI.Lib.Data.DTO.Match
{
    public class FinishingDamageDto
    {
        public string damageType;

        public string damageItem;

        public bool isSecondaryFireMode;
    }
}
