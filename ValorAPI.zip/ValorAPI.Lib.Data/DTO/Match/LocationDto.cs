﻿namespace ValorAPI.Lib.Data.DTO.Match
{
    public class LocationDto
    {
        public int x;

        public int y;
    }
}
