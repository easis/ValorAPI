﻿namespace ValorAPI.Lib.Data.DTO.Content
{
    public class ContentItemDto
    {
        public string name;

        public LocalizedNamesDto localizedNames;

        public string id;

        public string assetName;

        public string assetPath;
    }
}
