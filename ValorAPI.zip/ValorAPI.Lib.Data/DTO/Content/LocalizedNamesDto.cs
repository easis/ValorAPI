﻿namespace ValorAPI.Lib.Data.DTO.Content
{
    public class LocalizedNamesDto
    {
        public string ar_AE;
        public string de_DE;
        public string en_GB;
        public string en_US;
        public string es_ES;
        public string es_MX;
        public string fr_FR;
        public string id_ID;
        public string it_IT;
        public string ja_JP;
        public string ko_KR;
        public string pl_PL;
        public string pt_BR;
        public string ru_RU;
        public string th_TH;
        public string tr_TR;
        public string vi_VN;
        public string zh_CN;
        public string zh_TW;
    }
}
